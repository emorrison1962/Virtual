﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NugetPackAndPush
{
    static class Constants
    {
        public const int ERROR_SUCCESS = 0;
        public const int INVALID = -1;
    }
}
