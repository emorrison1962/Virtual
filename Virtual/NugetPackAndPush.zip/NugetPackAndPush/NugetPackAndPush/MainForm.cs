﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Windows.Forms;
using System.Xml.Linq;

namespace NugetPackAndPush
{
    public partial class MainForm : Form
    {

        //const string PUBLISH_CMD_FORMAT = @"nuget push ""{0}"" -k EPS -s http://us007-pc-itxx01/nuget/ -d --verbosity detailed";
        //const string PUBLISH_CMD_FORMAT = @"nuget push ""{0}"" -k METX_CI_NugetServer2015! -s ""http://us002-pc-tfs03.goevo.com/EVO NuGet Server/NuGet"" -d --verbosity detailed";

        const string EPS_APIKEY = "EPS";
        const string EPS_NUGET_REPO = "http://us007-pc-itxx01/nuget/nuget/";
        const string GOEVO_APIKEY = "METX_CI_NugetServer2015!";
        const string GOEVO_NUGET_REPO = @"http://us002-pc-tfs03.goevo.com/EVO NuGet Server/NuGet";


        //NugetRepository _epsRepo = new NugetRepository(EPS_NUGET_REPO, EPS_APIKEY);
        //NugetRepository _goevoRepo = new NugetRepository(GOEVO_NUGET_REPO, GOEVO_APIKEY);


        #region Constants

        const string CF_VSREFPROJECTS = "CF_VSREFPROJECTS";
        const string CF_FILENAME = "FileNameW";

        #endregion

        #region Properties

        string ProjectPath
        {
            get
            {
                return Properties.Settings.Default["LastProject"].ToString();
            }
            set
            {
                Properties.Settings.Default["LastProject"] = value;
                Properties.Settings.Default.Save();
                this.ProjectPathChanged();
            }
        }

        string NugetPath
        {
            get
            {
                return Properties.Settings.Default["NugetPath"].ToString();
            }
            set
            {
                Properties.Settings.Default["NugetPath"] = value;
                Properties.Settings.Default.Save();
            }
        }

        ReleaseType _releaseType;
        ReleaseType ReleaseType
        {
            get { return _releaseType; }
            set
            {
                _releaseType = value;
                this.UpdateRadioButtons();
            }
        }

        public bool UpdateNuSpec { get; private set; }

        public List<NugetRepository> Repositories { get; private set; } = new List<NugetRepository>();
        public NugetRepository SelectedRepo
        {
            get
            {
                var repoName = Properties.Settings.Default["SelectedRepo"].ToString();
                var result = this.Repositories.First(x => x.Name == repoName);
                Debug.Assert(null != result);
                return result; 
            }
            private set
            {
                Properties.Settings.Default["SelectedRepo"] = value.Name;
                Properties.Settings.Default.Save();
            }
        }
        #endregion

        void UpdateRadioButtons()
        {
            _rbRelease.CheckedChanged -= _rbRelease_CheckedChanged;
            _rbReleaseCandidate.CheckedChanged -= _rbReleaseCandidate_CheckedChanged;
            _rbBeta.CheckedChanged -= _rbBeta_CheckedChanged;
            _rbAlpha.CheckedChanged -= _rbAlpha_CheckedChanged;

            if (this.ReleaseType.IsRelease)
                _rbRelease.Checked = true;
            else if (this.ReleaseType.IsReleaseCandidate)
                _rbReleaseCandidate.Checked = true;
            else if (this.ReleaseType.IsBeta)
                _rbBeta.Checked = true;
            else if (this.ReleaseType.IsAlpha)
                _rbAlpha.Checked = true;

            _rbRelease.CheckedChanged += _rbRelease_CheckedChanged;
            _rbReleaseCandidate.CheckedChanged += _rbReleaseCandidate_CheckedChanged;
            _rbBeta.CheckedChanged += _rbBeta_CheckedChanged;
            _rbAlpha.CheckedChanged += _rbAlpha_CheckedChanged;

        }


        #region Construction
        public MainForm()
        {
            InitializeComponent();
            this.ReleaseType = ReleaseType.Alpha;
        }

        #endregion

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            var screenSize = Screen.AllScreens[1].WorkingArea.Size;
            var offset = screenSize.Width - this.Size.Width;

            this.Location = new Point(Screen.AllScreens[1].WorkingArea.Location.X + offset, Screen.AllScreens[1].WorkingArea.Location.Y);
            if (!string.IsNullOrEmpty(this.ProjectPath))
            {
                this._bnPublish.Enabled = true;
            }

            this.LoadRepoCombo();
        }

        private void LoadRepoCombo()
        {
            var assembly = Assembly.GetExecutingAssembly();
            using (var stream = assembly.GetManifestResourceStream("NugetPackAndPush.Repositories.xml"))
            {
                using (var reader = new StreamReader(stream))
                {
                    var doc = XDocument.Load(stream);
                    Debug.WriteLine(doc.ToString());
                    var repos = doc.Root.Descendants("Repository");
                    foreach (var repo in repos)
                    {
                        var name = repo.Descendants("Name").First().Value;
                        var url = repo.Descendants("Url").First().Value;
                        var apiKey = repo.Descendants("ApiKey").First().Value;
                        var r = new NugetRepository(name, url, apiKey);
                        this.Repositories.Add(r);
                    }
                }
            }

            this.Repositories = this.Repositories.OrderBy(x => x.Name).ToList();
            foreach (var r in this.Repositories)
            {
                this._comboRepos.Items.Add(r.Name);
            }

            var ndx = 0;
            var selectedRepo = this.SelectedRepo;
            if (null == selectedRepo)
            {
                this._comboRepos.SelectedItem = this._comboRepos.Items[0];
            }
            else
            {
                ndx = this._comboRepos.Items.IndexOf(this.SelectedRepo.Name);
            }
            this._comboRepos.SelectedItem = this._comboRepos.Items[ndx];

        }

        void ProjectPathChanged()
        {
            const string DEFAULT_CAPTION = "Nuget Pack & Push";
            if (!string.IsNullOrEmpty(this.ProjectPath))
                this.Text = string.Format("{0} - {1}", this.ProjectPath, DEFAULT_CAPTION);
            else
                this.Text = string.Format("{0}", DEFAULT_CAPTION);

            _tbOutput.Clear();
        }

        private void _comboRepos_SelectedValueChanged(object sender, EventArgs e)
        {
            var repo = this.Repositories.Where(x => x.Name == _comboRepos.SelectedItem.ToString()).First();
            this.SelectedRepo = repo;
            this._tbOutput.Text = "";
        }
    }//class

}//ns
