﻿using System.Collections.Generic;
using System.Xml.Linq;

namespace NugetPackAndPush
{
    public static class XDocumentExtensions
    {
        public static IEnumerable<XElement> DescendantsEx(this XDocument doc, XName name)
        {
            XNamespace ns = doc.Root.Name.Namespace;
            var result = doc.Descendants(ns + name.ToString());
            return result;
        }
        public static IEnumerable<XElement> DescendantsEx(this XElement e, XName name)
        {
            XNamespace ns = e.Document.Root.Name.Namespace;
            var result = e.Descendants(ns + name.ToString());
            return result;
        }
        public static IEnumerable<XElement> DescendantsEx(this XElement e)
        {
            XNamespace ns = e.Document.Root.Name.Namespace;
            var result = e.Descendants();
            return result;
        }

    }
}
