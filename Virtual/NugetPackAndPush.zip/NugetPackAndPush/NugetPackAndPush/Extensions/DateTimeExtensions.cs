﻿using System;

namespace NugetPackAndPush
{
    public static class DateTimeExtensions
    {
        public static bool IsToday(this DateTime dt)
        {
            var result = false;
            var now = DateTime.Now;
            if (dt.Year == now.Year)
                if (dt.Month == now.Month)
                    if (dt.Date == now.Date)
                        result = true;
            return result;
        }
    }
}
