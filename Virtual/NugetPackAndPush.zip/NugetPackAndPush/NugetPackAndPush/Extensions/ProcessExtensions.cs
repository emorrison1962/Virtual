﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NugetPackAndPush
{
    static public class ProcessExtensions
    {
        public static ProcessStartInfo CreateProcessStartInfo(string filename, string arguments)
        {
            var result = new ProcessStartInfo();
            result.Arguments = arguments;
            result.FileName = filename;
            result.UseShellExecute = false;
            result.RedirectStandardOutput = true;
            result.RedirectStandardError = true;
            return result;
        }

        public static int SpawnProcess(IProcessObserver observer, ProcessStartInfo si)
        {
            int result = int.MaxValue;
            try
            {
                var p = new Process();
                p.StartInfo = si;

                if (p.StartInfo.RedirectStandardOutput)
                    p.OutputDataReceived += observer.ProcessObserver_OutputDataReceived;
                if (p.StartInfo.RedirectStandardError)
                    p.ErrorDataReceived += observer.ProcessObserver_ErrorDataReceived;

                Debug.WriteLine(string.Format("{0} {1}", si.FileName, si.Arguments));
                p.Start();

                if (p.StartInfo.RedirectStandardOutput)
                    p.BeginOutputReadLine();
                if (p.StartInfo.RedirectStandardError)
                    p.BeginErrorReadLine();

                p.WaitForExit();
                result = p.ExitCode;

                if (Constants.ERROR_SUCCESS != result)
                    new Object();
            }
#pragma warning disable 0168
            catch (Exception ex)
            {
                throw;
            }
#pragma warning restore 0168
            return result;
        }


    }
}
