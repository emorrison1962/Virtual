﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace NugetPackAndPush
{
    public partial class MainForm
    {

        #region Event Handlers

        public void CurrentDomain_UnhandledException(object sender, UnhandledExceptionEventArgs e)
        {
            MessageBox.Show(e.ExceptionObject.ToString(), "WHOA...an unhandled exception was caught", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        public void Application_ThreadException(object sender, ThreadExceptionEventArgs e)
        {
            MessageBox.Show(e.Exception.ToString(), "WHOA...an unhandled exception was caught", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }



        private void NugetHelper_OutputDataReceived(object sender, DataReceivedEventArgs e)
        {
            if (null != e.Data)
            {
                var text = e.Data.ToString() + Environment.NewLine;

                this.BeginInvoke((Action)delegate ()
                {
                    this._tbOutput.AppendText(text);
                });

                Debug.WriteLine(e.Data.ToString());
            }
        }

        void LoadNuSpec(string path = null)
        {
            this.UpdateNuSpec = true;
            if (null != path)
                this.ProjectPath = path;

            var nuSpecPath = this.ProjectPath.ToLower().Replace(".csproj", ".nuspec");
            if (File.Exists(nuSpecPath))
            {
                var doc = XDocument.Load(nuSpecPath);
                this._tbOutput.Text = doc.ToString();
                var ctx = this.CreateNugetContext();
                try
                {
                    this.ReleaseType = new VersionParser(this.CreateNugetContext(), doc).ReleaseType;
                    this._bnPublish.Enabled = true;
                }
                catch (Exception ex)
                {
                    this.HandleException(ex);
                }
            }
            else
            {
                this._bnSpec_Click(this, null);
            }

        }

        private void _bnBrowse_Click(object sender, EventArgs e)
        {
            var dlg = new OpenFileDialog();
            dlg.DefaultExt = ".csproj";
            dlg.Filter = "Project Files (*.csproj)|*.csproj";
            if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                this.LoadNuSpec(dlg.FileName);
            }
        }

        private void _bnOk_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void _bnOptions_Click(object sender, EventArgs e)
        {
            var dlg = new OptionsDlg();
            dlg.StartPosition = FormStartPosition.CenterScreen;

            dlg.ShowDialog();
        }

        NugetContext CreateNugetContext()
        {
            var nugetPath = Properties.Settings.Default["NugetPath"].ToString();
            var result = new NugetContext(this.SelectedRepo, nugetPath, this.ProjectPath, this.ReleaseType, this.UpdateNuSpec);
            return result;
        }

        NugetHelper CreateNugetHelper()
        {
            var ctx = this.CreateNugetContext();
            var result = new NugetHelper(ctx);
            result.OutputDataReceived += NugetHelper_OutputDataReceived;
            result.OutputErrorReceived += NugetHelper_OutputDataReceived;
            return result;
        }

        private void _bnPublish_Click(object sender, EventArgs e)
        {
            _tbOutput.Clear();
            try
            {
                var helper = this.CreateNugetHelper();
                bool result = helper.PackAndPush();
                this.UpdateNuSpec = true;
            }
            catch (Exception ex)
            {
                this.HandleException(ex);
            }
        }

        private void _bnSpec_Click(object sender, EventArgs e)
        {
            _tbOutput.Clear();
            var helper = this.CreateNugetHelper();
            try
            {
                bool result = helper.Spec(this.ReleaseType);
                if (result)
                    this.UpdateNuSpec = false;

                LoadNuSpec();
            }
            catch (Exception ex)
            {
                this.HandleException(ex);
            }
        }

        void HandleException(Exception ex)
        {
            var bx = ex.GetBaseException();
            this._tbOutput.BackColor = System.Drawing.Color.Red;
            this._tbOutput.Text = bx.Message;
        }

        private void _rbRelease_CheckedChanged(object sender, EventArgs e)
        {
            if (_rbRelease.Checked)
                this.ReleaseType = ReleaseType.Standard;
        }

        private void _rbReleaseCandidate_CheckedChanged(object sender, EventArgs e)
        {
            if (_rbReleaseCandidate.Checked)
                this.ReleaseType = ReleaseType.ReleaseCandidate;
        }

        private void _rbBeta_CheckedChanged(object sender, EventArgs e)
        {
            if (_rbBeta.Checked)
                this.ReleaseType = ReleaseType.Beta;
        }

        private void _rbAlpha_CheckedChanged(object sender, EventArgs e)
        {
            if (_rbAlpha.Checked)
                this.ReleaseType = ReleaseType.Alpha;
        }



        #region Drag and Drop

        private void MainForm_DragEnter(object sender, DragEventArgs e)
        {
            Debug.WriteLine(MethodInfo.GetCurrentMethod().Name);
            if (e.Data.GetDataPresent(CF_FILENAME) || e.Data.GetDataPresent(CF_VSREFPROJECTS))
                e.Effect = DragDropEffects.Move;
            else
                e.Effect = DragDropEffects.None;
        }

        private void MainForm_DragDrop(object sender, DragEventArgs e)
        {
            Debug.WriteLine(MethodInfo.GetCurrentMethod().Name);

            string path = null;
            string parsed = null;

            if (e.Data.GetDataPresent(CF_FILENAME))
            {
                if (GetFilenameFrom_CF_FILENAME(e, out parsed))
                {
                    path = parsed;
                }
            }
            else if (e.Data.GetDataPresent(CF_VSREFPROJECTS))
            {
                if (GetFilenameFrom_CF_VSREFPROJECTS(e, out parsed))
                {
                    path = parsed;
                }
            }

            if (!string.IsNullOrEmpty(path))
                this.LoadNuSpec(path);
        }

        bool GetFilenameFrom_CF_FILENAME(DragEventArgs e, out string path)
        {
            var result = false;
            path = null;
            var filenames = e.Data.GetData(CF_FILENAME) as string[];
            if (null != filenames)
            {
                var candidate = filenames.ToList().FirstOrDefault();
                if (candidate.Contains(".csproj"))
                {
                    path = candidate;
                    result = true;
                }
            }
            return result;
        }
        bool GetFilenameFrom_CF_VSREFPROJECTS(DragEventArgs e, out string path)
        {
            bool result = false;
            path = null;

            var obj = e.Data.GetData(CF_VSREFPROJECTS);
            using (MemoryStream ms = obj as MemoryStream)
            {
                if (ms != null)
                {
                    string projectInfo = String.Empty;
                    String data = Encoding.Unicode.GetString(ms.ToArray());
                    StringBuilder sb = new StringBuilder();
                    for (int ix = 0; ix < data.Length; ix++)
                    {
                        char ch = data[ix];
                        if (ch == 0)
                        {
                            if (sb.Length > 2)
                                projectInfo = sb.ToString();
                            if (sb.Length != 0)
                                sb = new StringBuilder();
                            continue;
                        }
                        sb.Append(ch);
                    }

                    var pi = projectInfo.Split('|').ToList();
                    if (pi.Count >= 3)
                    {
                        var filename = Path.GetFileName(pi[1]);
                        //"MixApi.Flex.Data.Entities.csproj"
                        var dir = Path.GetDirectoryName(pi[2]);
                        //"c:\\dev\\simplification\\merchants api\\mixapi.flex.data.entities"
                        if (File.Exists(Path.Combine(dir, filename)))
                        {
                            path = Path.Combine(dir, filename);
                            result = true;
                        }
                    }
                }
            }
            return result;
        }


        #endregion

        #endregion

    }//class
}//ns
