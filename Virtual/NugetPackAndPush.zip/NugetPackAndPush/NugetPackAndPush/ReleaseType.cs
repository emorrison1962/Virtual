﻿using System;

namespace NugetPackAndPush
{
    public class ReleaseType
    {
        const string ALPHA = "-alpha";
        const string BETA = "-beta";
        const string RC = "-rc";

        static public ReleaseType Standard = new ReleaseType(ReleaseTypeEnum.Standard);
        static public ReleaseType Alpha = new ReleaseType(ReleaseTypeEnum.Alpha);
        static public ReleaseType Beta = new ReleaseType(ReleaseTypeEnum.Beta);
        static public ReleaseType ReleaseCandidate = new ReleaseType(ReleaseTypeEnum.ReleaseCandidate);

        enum ReleaseTypeEnum
        {
            Standard,
            Alpha,
            Beta,
            ReleaseCandidate
        };

        ReleaseTypeEnum _releaseType = ReleaseTypeEnum.Standard;

        ReleaseType(ReleaseTypeEnum releaseType)
        {
            this._releaseType = releaseType;
        }

        public bool IsRelease
        {
            get { return _releaseType == ReleaseTypeEnum.Standard; }
            private set { _releaseType = ReleaseTypeEnum.Standard; }
        }
        public bool IsAlpha
        {
            get { return _releaseType == ReleaseTypeEnum.Alpha; }
            private set { _releaseType = ReleaseTypeEnum.Alpha; }
        }
        public bool IsBeta
        {
            get { return _releaseType == ReleaseTypeEnum.Beta; }
            private set { _releaseType = ReleaseTypeEnum.Beta; }
        }
        public bool IsReleaseCandidate
        {
            get { return _releaseType == ReleaseTypeEnum.ReleaseCandidate; }
            private set { _releaseType = ReleaseTypeEnum.ReleaseCandidate; }
        }

        public override string ToString()
        {
            var result = string.Empty;
            if (this.IsAlpha)
            {
				//result = string.Format("{0}", ALPHA);
#warning *** FIXME ***
				var username = Environment.UserName.Replace(".", "_");
				result = string.Format("-{0}", username);
            }
            else if (this.IsBeta)
                result = BETA;
            else if (this.IsReleaseCandidate)
                result = RC;
            return result;
        }
    }
}
