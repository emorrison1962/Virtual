﻿namespace NugetPackAndPush
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this._bnBrowse = new System.Windows.Forms.Button();
            this._bnOk = new System.Windows.Forms.Button();
            this._bnPublish = new System.Windows.Forms.Button();
            this._bnOptions = new System.Windows.Forms.Button();
            this._tbOutput = new System.Windows.Forms.TextBox();
            this._bnSpec = new System.Windows.Forms.Button();
            this._pnlButton = new System.Windows.Forms.Panel();
            this._rbAlpha = new System.Windows.Forms.RadioButton();
            this._rbBeta = new System.Windows.Forms.RadioButton();
            this._rbReleaseCandidate = new System.Windows.Forms.RadioButton();
            this._rbRelease = new System.Windows.Forms.RadioButton();
            this._pnlRepos = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this._comboRepos = new System.Windows.Forms.ComboBox();
            this._pnlButton.SuspendLayout();
            this._pnlRepos.SuspendLayout();
            this.SuspendLayout();
            // 
            // _bnBrowse
            // 
            this._bnBrowse.Location = new System.Drawing.Point(4, 39);
            this._bnBrowse.Margin = new System.Windows.Forms.Padding(4);
            this._bnBrowse.Name = "_bnBrowse";
            this._bnBrowse.Size = new System.Drawing.Size(100, 28);
            this._bnBrowse.TabIndex = 0;
            this._bnBrowse.Text = "csproj...";
            this._bnBrowse.UseVisualStyleBackColor = true;
            this._bnBrowse.Click += new System.EventHandler(this._bnBrowse_Click);
            // 
            // _bnOk
            // 
            this._bnOk.DialogResult = System.Windows.Forms.DialogResult.OK;
            this._bnOk.Location = new System.Drawing.Point(3, 447);
            this._bnOk.Margin = new System.Windows.Forms.Padding(4);
            this._bnOk.Name = "_bnOk";
            this._bnOk.Size = new System.Drawing.Size(100, 28);
            this._bnOk.TabIndex = 1;
            this._bnOk.Text = "OK";
            this._bnOk.UseVisualStyleBackColor = true;
            this._bnOk.Click += new System.EventHandler(this._bnOk_Click);
            // 
            // _bnPublish
            // 
            this._bnPublish.Enabled = false;
            this._bnPublish.Location = new System.Drawing.Point(-1, 230);
            this._bnPublish.Margin = new System.Windows.Forms.Padding(4);
            this._bnPublish.Name = "_bnPublish";
            this._bnPublish.Size = new System.Drawing.Size(100, 28);
            this._bnPublish.TabIndex = 2;
            this._bnPublish.Text = "Publish";
            this._bnPublish.UseVisualStyleBackColor = true;
            this._bnPublish.Click += new System.EventHandler(this._bnPublish_Click);
            // 
            // _bnOptions
            // 
            this._bnOptions.Location = new System.Drawing.Point(4, 4);
            this._bnOptions.Margin = new System.Windows.Forms.Padding(4);
            this._bnOptions.Name = "_bnOptions";
            this._bnOptions.Size = new System.Drawing.Size(100, 28);
            this._bnOptions.TabIndex = 4;
            this._bnOptions.Text = "Options...";
            this._bnOptions.UseVisualStyleBackColor = true;
            this._bnOptions.Click += new System.EventHandler(this._bnOptions_Click);
            // 
            // _tbOutput
            // 
            this._tbOutput.AllowDrop = true;
            this._tbOutput.BackColor = System.Drawing.Color.CornflowerBlue;
            this._tbOutput.Dock = System.Windows.Forms.DockStyle.Fill;
            this._tbOutput.Font = new System.Drawing.Font("Consolas", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this._tbOutput.Location = new System.Drawing.Point(0, 48);
            this._tbOutput.Margin = new System.Windows.Forms.Padding(4);
            this._tbOutput.Multiline = true;
            this._tbOutput.Name = "_tbOutput";
            this._tbOutput.ReadOnly = true;
            this._tbOutput.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this._tbOutput.Size = new System.Drawing.Size(924, 442);
            this._tbOutput.TabIndex = 5;
            this._tbOutput.DragDrop += new System.Windows.Forms.DragEventHandler(this.MainForm_DragDrop);
            this._tbOutput.DragEnter += new System.Windows.Forms.DragEventHandler(this.MainForm_DragEnter);
            // 
            // _bnSpec
            // 
            this._bnSpec.Location = new System.Drawing.Point(0, 194);
            this._bnSpec.Margin = new System.Windows.Forms.Padding(4);
            this._bnSpec.Name = "_bnSpec";
            this._bnSpec.Size = new System.Drawing.Size(100, 28);
            this._bnSpec.TabIndex = 6;
            this._bnSpec.Text = "Spec";
            this._bnSpec.UseVisualStyleBackColor = true;
            this._bnSpec.Click += new System.EventHandler(this._bnSpec_Click);
            // 
            // _pnlButton
            // 
            this._pnlButton.Controls.Add(this._rbAlpha);
            this._pnlButton.Controls.Add(this._rbBeta);
            this._pnlButton.Controls.Add(this._rbReleaseCandidate);
            this._pnlButton.Controls.Add(this._rbRelease);
            this._pnlButton.Controls.Add(this._bnOk);
            this._pnlButton.Controls.Add(this._bnSpec);
            this._pnlButton.Controls.Add(this._bnBrowse);
            this._pnlButton.Controls.Add(this._bnPublish);
            this._pnlButton.Controls.Add(this._bnOptions);
            this._pnlButton.Dock = System.Windows.Forms.DockStyle.Right;
            this._pnlButton.Location = new System.Drawing.Point(924, 0);
            this._pnlButton.Margin = new System.Windows.Forms.Padding(4);
            this._pnlButton.Name = "_pnlButton";
            this._pnlButton.Size = new System.Drawing.Size(108, 490);
            this._pnlButton.TabIndex = 8;
            // 
            // _rbAlpha
            // 
            this._rbAlpha.AutoSize = true;
            this._rbAlpha.Location = new System.Drawing.Point(9, 164);
            this._rbAlpha.Margin = new System.Windows.Forms.Padding(4);
            this._rbAlpha.Name = "_rbAlpha";
            this._rbAlpha.Size = new System.Drawing.Size(65, 21);
            this._rbAlpha.TabIndex = 10;
            this._rbAlpha.TabStop = true;
            this._rbAlpha.Text = "Alpha";
            this._rbAlpha.UseVisualStyleBackColor = true;
            this._rbAlpha.CheckedChanged += new System.EventHandler(this._rbAlpha_CheckedChanged);
            // 
            // _rbBeta
            // 
            this._rbBeta.AutoSize = true;
            this._rbBeta.Location = new System.Drawing.Point(8, 134);
            this._rbBeta.Margin = new System.Windows.Forms.Padding(4);
            this._rbBeta.Name = "_rbBeta";
            this._rbBeta.Size = new System.Drawing.Size(58, 21);
            this._rbBeta.TabIndex = 9;
            this._rbBeta.TabStop = true;
            this._rbBeta.Text = "Beta";
            this._rbBeta.UseVisualStyleBackColor = true;
            this._rbBeta.CheckedChanged += new System.EventHandler(this._rbBeta_CheckedChanged);
            // 
            // _rbReleaseCandidate
            // 
            this._rbReleaseCandidate.AutoSize = true;
            this._rbReleaseCandidate.Location = new System.Drawing.Point(9, 106);
            this._rbReleaseCandidate.Margin = new System.Windows.Forms.Padding(4);
            this._rbReleaseCandidate.Name = "_rbReleaseCandidate";
            this._rbReleaseCandidate.Size = new System.Drawing.Size(48, 21);
            this._rbReleaseCandidate.TabIndex = 8;
            this._rbReleaseCandidate.TabStop = true;
            this._rbReleaseCandidate.Text = "RC";
            this._rbReleaseCandidate.UseVisualStyleBackColor = true;
            this._rbReleaseCandidate.CheckedChanged += new System.EventHandler(this._rbReleaseCandidate_CheckedChanged);
            // 
            // _rbRelease
            // 
            this._rbRelease.AutoSize = true;
            this._rbRelease.Location = new System.Drawing.Point(9, 76);
            this._rbRelease.Margin = new System.Windows.Forms.Padding(4);
            this._rbRelease.Name = "_rbRelease";
            this._rbRelease.Size = new System.Drawing.Size(81, 21);
            this._rbRelease.TabIndex = 7;
            this._rbRelease.TabStop = true;
            this._rbRelease.Text = "Release";
            this._rbRelease.UseVisualStyleBackColor = true;
            this._rbRelease.CheckedChanged += new System.EventHandler(this._rbRelease_CheckedChanged);
            // 
            // _pnlRepos
            // 
            this._pnlRepos.Controls.Add(this.label1);
            this._pnlRepos.Controls.Add(this._comboRepos);
            this._pnlRepos.Dock = System.Windows.Forms.DockStyle.Top;
            this._pnlRepos.Location = new System.Drawing.Point(0, 0);
            this._pnlRepos.Name = "_pnlRepos";
            this._pnlRepos.Size = new System.Drawing.Size(924, 48);
            this._pnlRepos.TabIndex = 9;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(122, 17);
            this.label1.TabIndex = 1;
            this.label1.Text = "Nuget Repository:";
            // 
            // _comboRepos
            // 
            this._comboRepos.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this._comboRepos.FormattingEnabled = true;
            this._comboRepos.Location = new System.Drawing.Point(140, 12);
            this._comboRepos.Name = "_comboRepos";
            this._comboRepos.Size = new System.Drawing.Size(189, 24);
            this._comboRepos.TabIndex = 0;
            this._comboRepos.SelectedValueChanged += new System.EventHandler(this._comboRepos_SelectedValueChanged);
            // 
            // MainForm
            // 
            this.AllowDrop = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1032, 490);
            this.Controls.Add(this._tbOutput);
            this.Controls.Add(this._pnlRepos);
            this.Controls.Add(this._pnlButton);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "Nuget Pack & Push";
            this.DragDrop += new System.Windows.Forms.DragEventHandler(this.MainForm_DragDrop);
            this.DragEnter += new System.Windows.Forms.DragEventHandler(this.MainForm_DragEnter);
            this._pnlButton.ResumeLayout(false);
            this._pnlButton.PerformLayout();
            this._pnlRepos.ResumeLayout(false);
            this._pnlRepos.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button _bnBrowse;
        private System.Windows.Forms.Button _bnOk;
        private System.Windows.Forms.Button _bnPublish;
        private System.Windows.Forms.Button _bnOptions;
        private System.Windows.Forms.TextBox _tbOutput;
        private System.Windows.Forms.Button _bnSpec;
        private System.Windows.Forms.Panel _pnlButton;
        private System.Windows.Forms.RadioButton _rbAlpha;
        private System.Windows.Forms.RadioButton _rbBeta;
        private System.Windows.Forms.RadioButton _rbReleaseCandidate;
        private System.Windows.Forms.RadioButton _rbRelease;
        private System.Windows.Forms.Panel _pnlRepos;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox _comboRepos;
    }
}

