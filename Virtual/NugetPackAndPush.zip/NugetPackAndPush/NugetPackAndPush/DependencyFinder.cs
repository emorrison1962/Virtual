﻿using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Xml.Linq;

namespace NugetPackAndPush
{
    public class DependencyFinder
    {
        string DevDirectory { get; set; }
        string PackageName { get; set; }
        public List<string> FindConsumers(string packageName)
        {
            var result = new List<string>();
            this.PackageName = packageName;
            this.DevDirectory = Path.Combine("c:\\", "dev", "eps");
            var projects = this.GetProjectPaths();


            foreach (var project in projects)
            {
                if (this.ProjectHasDependency(project))
                {
                    result.Add(project);
                }
            }

            return result;
        }

        List<string> GetProjectPaths()
        {
            var result = new List<string>();
            result = Directory.GetFiles(DevDirectory, "*.csproj", SearchOption.AllDirectories).ToList();
            return result;
        }

        XDocument LoadProject(string path)
        {
            var result = XDocument.Load(path);
            Debug.Assert(null != result);
            return result;
        }


        bool ProjectHasDependency(string projectPath)
        {
            var result = false;
            var doc = this.LoadProject(projectPath);

            var root = doc.Root;
            var refs = root.DescendantsEx("Reference");

            foreach (var r in refs)
            {
                var val = r.FirstAttribute.Value;
                if (val.Contains(this.PackageName))
                {
                    var reference = val.Split(',').First();
                    if (reference == this.PackageName)
                    {
                        result = true;
                    }
                }
            }

            return result;
        }

    }
}
