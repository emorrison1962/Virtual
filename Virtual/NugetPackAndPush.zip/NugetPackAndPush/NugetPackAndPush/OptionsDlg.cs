﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NugetPackAndPush
{
    public partial class OptionsDlg : Form
    {
        const string REQUIRED_VERSION = "3.4.4.1321";

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            this.NugetPath = Properties.Settings.Default["NugetPath"].ToString();
            if (!string.IsNullOrEmpty(this.NugetPath))
                this._lblNugetPath.Text = this.NugetPath;
        }
        public OptionsDlg()
        {
            InitializeComponent();
        }

        string NugetPath { get; set; }
        private void _bnBrowseNuget_Click(object sender, EventArgs e)
        {
            var dlg = new OpenFileDialog();
            dlg.DefaultExt = ".exe";
            dlg.Filter = "Executable Files (*.exe)|*.exe";
            if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                if (this.VerifyNugetAssembly(dlg.FileName))
                {
                    this.NugetPath = dlg.FileName;
                    _lblNugetPath.Text = dlg.FileName;
                }
            }
        }

        private void _bnOK_Click(object sender, EventArgs e)
        {
            Properties.Settings.Default["NugetPath"] = this.NugetPath;
            Properties.Settings.Default.Save();

            this.Close();
        }

        bool VerifyNugetAssembly(string path)
        {
            var result = false;

            var requiredVersion = new Version(REQUIRED_VERSION);
            var assembly = Assembly.ReflectionOnlyLoadFrom(path);
            var version = assembly.GetName().Version;

            if (version >= requiredVersion)
            {
                result = true;
            }
            else
            {
                const string NUGET_URL = "https://dist.nuget.org/index.html";
                var msg = string.Format(
                    "NugetPackAndPush requires nuget.exe, version {0} or higher.{1}Visit {2}?", 
                    REQUIRED_VERSION, 
                    Environment.NewLine, 
                    NUGET_URL);

                var dlgResult = MessageBox.Show(msg, "NugetPackAndPush", MessageBoxButtons.YesNo, MessageBoxIcon.Asterisk);
                if (dlgResult == DialogResult.Yes)
                {
                    System.Diagnostics.Process.Start(NUGET_URL);
                }
            }

            return result;
        }
    }//class
}//ns
