﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Xml.Linq;

namespace NugetPackAndPush
{
    class VersionParser : IProcessObserver
    {
        //-alpha: Alpha release, typically used for work -in-progress and experimentation
        //-beta: Beta release, typically one that is feature complete for the next planned release, but may contain known bugs.
        //-rc: Release candidate, typically a release that's potentially final (stable) unless significant bugs emerge.

        #region Constants
        const string ALPHA = "-alpha";
        const string BETA = "-beta";
        const string RC = "-rc";
        const string NUGET_GENERATED_DEFAULT_VERSION = "$version$";
        const string VERSION_ZERO = "0.0.0";
        const string VERSION_ONE = "1.0.0";
        const string NONE = "No packages found.";
        const int DEFAULT_MAJOR_VERSION = 1;

        #endregion


        #region Properties
        public ReleaseType ReleaseType { get; set; }

        int VersionMajor { get; set; }
        int _versionYear;
        int VersionYear
        {
            get { return _versionYear; }
            set
            {
                _versionYear = value;
                if (_versionYear > 18)
                    Debug.Assert(false);
            }
        }
        int VersionDay { get; set; }
        int VersionMinor { get; set; }

        NugetContext Context { get; set; }
        string ErrorData { get; set; }
        string OutputData { get; set; }
        List<string> ServerVersions { get; set; }

        #endregion

        private VersionParser()
        {
            this.Init();
        }
        public VersionParser(NugetContext ctx, string version = null) : this()
        {
            this.Init(ctx);
            if (null != version && VERSION_ZERO != version)
                this.Parse(version);
        }

        public VersionParser(NugetContext ctx, XDocument doc) : this()
        {
            this.Init(ctx);
            if (!this.Parse(doc))
                throw new Exception("Could not parse XDocument.");
        }

        void Init()
        {
            var dt = DateTime.Now;
            this.VersionMajor = DEFAULT_MAJOR_VERSION;
            this.VersionYear = dt.Year - 2000;
            this.VersionDay = dt.DayOfYear;
            this.VersionMinor = 0;
            this.ReleaseType = ReleaseType.Alpha;
        }

        void Init(NugetContext ctx)
        {
            this.ServerVersions = new List<string>();
            this.Context = ctx;
            this.ReleaseType = ctx.ReleaseType;
        }

        public bool Parse(XDocument doc)
        {
            var version = doc.Root.DescendantsEx().Where(x => x.Name.LocalName == "version").FirstOrDefault();

            var success = false;
            if (null != version)
                success = true;
            if (success)
            {
                var parser = new VersionParser(this.Context, version.Value);
                this.ReleaseType = parser.ReleaseType;
                success = true;
            }
            return success;
        }


        public string Increment()
        {
            var dt = DateTime.Now;

            if (DateTime.Now.DayOfYear == this.VersionDay)
            {
                this.VersionMinor++;
            }
            else
            {
                this.Init();
            }
            return this.ToString();
        }

        private void Parse(string version)
        {
            this.GetVersionFromServer();

            if (NUGET_GENERATED_DEFAULT_VERSION == version ||
                VERSION_ONE == version)
            {
                version = VERSION_ZERO;
                this.ReleaseType = ReleaseType.Alpha;
            }

            //var userName = Environment.UserName;
            if (version.Contains(BETA))
            {
                this.ReleaseType = ReleaseType.Beta;
                version = version.Replace(BETA, string.Empty);
            }
            else if (version.Contains(RC))
            {
                this.ReleaseType = ReleaseType.ReleaseCandidate;
                version = version.Replace(RC, string.Empty);
            }
            else if (version.Contains("-"))
            {
                this.ReleaseType = ReleaseType.Alpha;
                var ndx = version.IndexOf("-");
                if (Constants.INVALID < ndx)
                {
                    version = version.Substring(0, ndx);
                }
            }

            var strings = version.Split('.').ToList();

            Debug.Assert(4 == strings.Count);
            var digits = strings.ConvertAll<int>(x => Convert.ToInt32(x));

            const int EXPECTED_COUNT = 4;
            if (EXPECTED_COUNT == digits.Count)
            {
                this.VersionMajor = digits[0];
                var yearDay = digits[2];
                this.VersionDay = yearDay % 1000;
                this.VersionYear = yearDay / 1000;
                this.VersionMinor = digits[3];
            }
            else
                throw new ArgumentException("Could not parse version from \"{0}\".", version);

        }

        public override string ToString()
        {
            var result = string.Format("{0}.0.{1:D2}{2:D03}.{3}",
                this.VersionMajor,
                this.VersionYear,
                this.VersionDay,
                this.VersionMinor);

            result += this.ReleaseType.ToString();
            return result;
        }

        public void GetVersionFromServer()
        {
            var CLI_FORMAT = "list {0} -source \"{1}\" -AllVersions -PreRelease";
            var cliCommand = string.Format(CLI_FORMAT, this.Context.ProjectName, this.Context.NugetRepository.Uri.ToString());

            var arguments = cliCommand;
            var fileName = this.Context.NugetPath;
            var si = ProcessExtensions.CreateProcessStartInfo(fileName, arguments);

            if (Constants.ERROR_SUCCESS == ProcessExtensions.SpawnProcess(this, si))
            {
                this.ProcessServerVersions();
            }
            else
            {
                throw new Exception(this.ErrorData);
            }
        }

        public void ProcessObserver_ErrorDataReceived(object sender, DataReceivedEventArgs e)
        {
            if (null != e.Data)
            {
                var text = e.Data.ToString() + Environment.NewLine;
                this.ErrorData += text;
                //Debug.WriteLine(e.Data.ToString());
            }
        }

        public void ProcessObserver_OutputDataReceived(object sender, DataReceivedEventArgs e)
        {
            if (null != e.Data)
            {
                var str = e.Data.ToString();
                if (NONE != str)
                {
                    this.ServerVersions.Add(str);
                    //var text = e.Data.ToString() + Environment.NewLine;
                    //this.OutputData += text;
                    //Debug.WriteLine(e.Data.ToString());
                }
            }
        }

        private void ProcessServerVersions()
        {
            this.ServerVersions.Sort();
            var tmp = new List<string>();

            foreach (var s in this.ServerVersions)
            {
                var s2 = s.Replace(this.Context.ProjectName, string.Empty).Trim();
                if (!s2.Contains(" "))
                {
                    if (s2.Contains(Environment.UserName))
                    {
                        tmp.Add(s2);
                    }
                }
            }

#warning **** TODO ****
#if false
            @"if versions exist on server
{
    if a version is mine
    {
        if version == today's date
        {
            increment digits
        }
    }
    else
    {
        set digits to date
    }"
}
#endif

            tmp.ForEach(x => Debug.WriteLine(x));
        }

    }//class
}
