﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Xml.Linq;

namespace NugetPackAndPush
{
    public class NugetHelper : IProcessObserver
    {
        const string DEPENDENCIES = "dependencies";
        const int INVALID = -1;

        public DataReceivedEventHandler OutputDataReceived;
        public DataReceivedEventHandler OutputErrorReceived;

        NugetContext Context { get; set; }
        string AssemblyInfoPath { get; set; }

        public NugetHelper(NugetContext ctx)
        {
            this.Context = ctx;
            Environment.CurrentDirectory = Path.GetDirectoryName(this.Context.ProjectPath);

        }

        public bool PackAndPush()
        {
            var success = false;
            if (Context.UpdateNuSpec)
                success = this.Spec(this.Context.ReleaseType);
            else
                success = true;

            if (success)
                success = this.Pack();
            if (success)
            {
                success = this.Publish();
            }
            return success;
        }

        public bool Spec(ReleaseType releaseType)
        {
            var result = false;

            var nuSpecPath = this.Context.ProjectPath.ToLower().Replace(".csproj", ".nuspec");
            if (!File.Exists(nuSpecPath))
            {
                this.CreateNuSpec(releaseType);
                result = true;
            }
            else
            {
                UpdateNuSpec(nuSpecPath);
                result = true;
            }
            return result;
        }

        const string PACKAGES_CONFIG = "packages.config";

        void CreateNuSpec(ReleaseType releaseType)
        {
            #region NUSPEC_TEMPLATE

            const string NUSPEC_TEMPLATE = @"<?xml version=""1.0""?>
<package>
  <metadata>
    <id>$id$</id>
    <version>{0}</version>
    <title>$title$</title>
    <authors>EVO</authors>
    <owners>$author$</owners>
    <requireLicenseAcceptance>false</requireLicenseAcceptance>
    <description>{4}</description>
    <releaseNotes>Published by NugetPackAndPush on {1} {2}.</releaseNotes>
    <copyright>Copyright {3}</copyright>
    <tags></tags>
    <dependencies></dependencies>
  </metadata>
  <files>
    <file src=""bin\Debug\{4}.pdb"" target=""lib\net45"" />
  </files>
</package>";

            #endregion

            try
            {
                var parser = new VersionParser(this.Context);//this.UpdateAssemblyInfo();
                var projectName = Context.ProjectName;

                var nuspec = string.Format(NUSPEC_TEMPLATE,
                    parser.ToString(),
                    DateTime.Now.ToShortDateString(),
                    DateTime.Now.ToShortTimeString(),
                    DateTime.Now.Year.ToString(),
                    projectName);

                var doc = XDocument.Parse(nuspec);
                this.ReplaceSampleNugetValues(doc);

                this.AddDependencies(doc);
                var nuspecPath = Context.ProjectPath.Replace(".csproj", ".nuspec");
                doc.Save(nuspecPath);
            }
            catch (Exception)
            {
                throw;
            }
        }

        const string METADATA = "metadata";
        void AddDependencies(XDocument doc)
        {
            var dependencies = this.GetDependencies();

            if (dependencies.Count > 0)
            {
                var node = doc.DescendantsEx(DEPENDENCIES).FirstOrDefault();
                if (null == node)
                {
                    var metadata = doc.DescendantsEx(METADATA).FirstOrDefault();
                    node = new XElement(DEPENDENCIES);
                    metadata.Add(node);
                }
                if (null != node)
                {
                    node.RemoveAll();
                    dependencies.ForEach(x => node.Add(x));
                }
            }
        }
        List<XElement> GetDependencies()
        {
            var result = new List<XElement>();
            var projectPath = Path.GetDirectoryName(this.Context.ProjectPath);
            var path = Path.Combine(projectPath, PACKAGES_CONFIG);
            if (File.Exists(path))
            {
                var doc = XDocument.Load(path);
                var nodes = doc.Root.DescendantsEx().Where(x => x.Name.LocalName == "package").ToList();
                foreach (var node in nodes)
                {
                    node.SetAttributeValue("targetFramework", null);
                    if (null == node.Attribute("developmentDependency"))
                        result.Add(node);
                }
            }
            result.ForEach(x => x.Name = "dependency");
            return result;
        }

        [Obsolete("", true)]
        VersionParser UpdateAssemblyInfo()
        {
            VersionParser parser = null;
            var templatedContent = string.Empty;
            if (GetVersionFromAssemblyInfo(out parser, out templatedContent))
            {
                parser.Increment();
                var contents = string.Format(templatedContent, parser.ToString());
                this.SaveAssemblyInfo(contents);
            }
            else
            {
                throw new Exception("Could not parse AssemblyInfo.");
            }
            return parser;
        }

        [Obsolete("", true)]
        private void SaveAssemblyInfo(string contents)
        {
            using (var sr = File.CreateText(this.AssemblyInfoPath))
            {
                sr.Write(contents);
            }
        }

        [Obsolete("", true)]
        bool GetVersionFromAssemblyInfo(out VersionParser version, out string templatedFileContents)
        {
            var success = false;
            version = null;
            templatedFileContents = string.Empty;

            try
            {
                this.AssemblyInfoPath = Directory.GetFiles(Path.GetDirectoryName(this.Context.ProjectPath),
                    "assemblyinfo.cs",
                    SearchOption.AllDirectories).LastOrDefault();
                if (!string.IsNullOrEmpty(this.AssemblyInfoPath))
                    success = true;
                if (success)
                {
                    success = false;
                    using (var sr = File.OpenText(this.AssemblyInfoPath))
                    {
                        var contents = sr.ReadToEnd();
                        const string START_TOKEN = "[assembly: AssemblyVersion(\"";
                        var start = contents.IndexOf(START_TOKEN);
                        if (INVALID < start)
                        {
                            start += START_TOKEN.Length;
                            const string END_TOKEN = "\")]";
                            var end = contents.IndexOf(END_TOKEN, start);
                            if (INVALID < end)
                            {
                                var sVersion = contents.Substring(start, end - start);
                                sVersion = sVersion.Replace("*", "0");
                                version = new VersionParser(this.Context, sVersion);
                                contents.Replace(sVersion, "{0}");
                                templatedFileContents = contents;
                                success = true;
                            }
                        }
                    }
                }
            }
#pragma warning disable 0168
            catch (Exception ex)
            {
                throw;
            }
#pragma warning restore 0168
            return success;
        }

        void ReplaceSampleNugetValues(XDocument doc)
        {
            const string EVO = "EVO Payments International";
            const string TAGS = "tags";
            const string SAMPLE_TAGS = "Tag1 Tag2";
            var projectName = Context.ProjectName;

            var node = doc.DescendantsEx("id").FirstOrDefault();
            if (null != node)
                if (node.Value == "$id$")
                    node.Value = projectName;

            node = doc.DescendantsEx("title").FirstOrDefault();
            if (null != node)
                if (node.Value == "$title$")
                    node.Value = projectName;

            node = doc.DescendantsEx("authors").FirstOrDefault();
            if (null != node)
                if (node.Value == "$author$")
                    node.Value = EVO;

            node = doc.DescendantsEx("owners").FirstOrDefault();
            if (null != node)
                if (node.Value == "$author$")
                    node.Value = EVO;

            node = doc.DescendantsEx("licenseUrl").FirstOrDefault();
            if (null != node)
                node.Remove();

            node = doc.DescendantsEx("projectUrl").FirstOrDefault();
            if (null != node)
                node.Remove();

            node = doc.DescendantsEx("iconUrl").FirstOrDefault();
            if (null != node)
                node.Remove();

            node = doc.DescendantsEx("description").FirstOrDefault();
            if (null != node)
                if (node.Value == "$description$")
                    node.Value = projectName;

            node = doc.DescendantsEx(TAGS).FirstOrDefault();
            if (null != node)
                if (node.Value == SAMPLE_TAGS)
                    node.Remove();

        }

        bool UpdateNuSpec(string nuSpecPath)
        {
            var result = false;
            try
            {
                var doc = XDocument.Load(nuSpecPath);
                this.ReplaceSampleNugetValues(doc);
                this.AddDependencies(doc);
                this.SetReleaseNotes(doc);

                #region Versioning
                var success = false;
                var version = doc.Root.DescendantsEx().Where(x => x.Name.LocalName == "version").FirstOrDefault();
                if (null != version)
                    success = true;
                if (success)
                {
                    var parser = new VersionParser(this.Context, version.Value);
                    version.Value = parser.Increment();
                }
                #endregion

                if (success)
                {
                    doc.Save(nuSpecPath);
                    result = true;
                }
            }
#pragma warning disable 0168
            catch (Exception ex)
            {
                throw;
            }
#pragma warning restore 0168

            return result;
        }

        private void SetReleaseNotes(XDocument doc)
        {
            const string RELEASE_NOTES = "releaseNotes";
            const string RELEASE_NOTES_FORMAT = "Published by NugetPackAndPush on {0} {1}.";
            var val = string.Format(RELEASE_NOTES_FORMAT,
                DateTime.Now.ToShortDateString(),
                DateTime.Now.ToShortTimeString());

            var node = doc.DescendantsEx(RELEASE_NOTES).FirstOrDefault();
            if (null != node)
                node.Value = val;
        }

        private bool Pack()
        {
            var result = false;
            try
            {
                var arguments = string.Format("pack \"{0}\"", this.Context.ProjectPath);
                var fileName = string.Format("\"{0}\"", this.Context.NugetPath);
                var si = ProcessExtensions.CreateProcessStartInfo(fileName, arguments);

                if (Constants.ERROR_SUCCESS == this.SpawnProcess(si))
                    result = true;
            }
#pragma warning disable 0168
            catch (Exception ex)
            {
                throw;
            }
#pragma warning restore 0168
            return result;
        }
        private bool Publish()
        {
            var result = false;
            var nupkg = this.GetLatest(Environment.CurrentDirectory, "*.nupkg");
            if (null != nupkg)
            {
                const string PUBLISH_CMD_FORMAT = @"nuget push ""{0}"" -k {1} -s ""{2}"" -d --verbosity detailed";

                var repo = this.Context.NugetRepository.Uri.ToString().ToLower();
#warning HACK ALERT!!!
                //http://us007-pc-itxx01/nuget/nuget/ won't let me publish with the double "nuget/". However, for a "nuget list" they're required.
                //What's going on here?
                const string TRAILING_NUGET = "/nuget";
                if (repo.EndsWith(TRAILING_NUGET))
                {
                    var ndx = repo.LastIndexOf(TRAILING_NUGET);
                    repo = repo.Remove(ndx, TRAILING_NUGET.Length);
                }


                var arguments = string.Format(PUBLISH_CMD_FORMAT,
                    nupkg,
                    this.Context.NugetRepository.ApiKey,
                    repo);
                var fileName = @"c:\Program Files\dotnet\dotnet.exe";
                var si = ProcessExtensions.CreateProcessStartInfo(fileName, arguments);

                if (Constants.ERROR_SUCCESS == this.SpawnProcess(si))
                    result = true;
            }
            else
            {
                throw new FileNotFoundException("*.nupkg");
            }
            return result;
        }

        string GetLatest(string path, string searchPattern)
        {
            var entries = Directory.GetFileSystemEntries(path, searchPattern).ToList();

            Converter<string, FileInfo> converter = x => new FileInfo(x);
            var fis = entries.ConvertAll(converter).ToList();

            FileInfo max = null;
            Action<FileInfo> selectMax = delegate (FileInfo fi)
            {
                if (max == null || max.LastWriteTime < fi.LastWriteTime)
                    max = fi;
            };
            fis.ForEach(selectMax);

            var result = max.FullName;
            return result;
        }

        int SpawnProcess(ProcessStartInfo si)
        {
            int result = int.MaxValue;
            try
            {
                var p = new Process();
                p.StartInfo = si;

                if (p.StartInfo.RedirectStandardOutput)
                    p.OutputDataReceived += ProcessObserver_OutputDataReceived;
                if (p.StartInfo.RedirectStandardError)
                    p.ErrorDataReceived += ProcessObserver_ErrorDataReceived;

                Debug.WriteLine(string.Format("{0} {1}", si.FileName, si.Arguments));
                p.Start();

                if (p.StartInfo.RedirectStandardOutput)
                    p.BeginOutputReadLine();
                if (p.StartInfo.RedirectStandardError)
                    p.BeginErrorReadLine();

                p.WaitForExit();
                result = p.ExitCode;

                if (Constants.ERROR_SUCCESS != result)
                    new Object();
            }
#pragma warning disable 0168
            catch (Exception ex)
            {
                throw;
            }
#pragma warning restore 0168
            return result;
        }

        public void ProcessObserver_ErrorDataReceived(object sender, DataReceivedEventArgs e)
        {
            if (null != e.Data)
                if (null != OutputErrorReceived)
                    this.OutputErrorReceived(sender, e);
        }

        public void ProcessObserver_OutputDataReceived(object sender, DataReceivedEventArgs e)
        {
            if (null != e.Data)
                if (null != OutputDataReceived)
                    this.OutputDataReceived(sender, e);
        }
    }//class
}//ns
