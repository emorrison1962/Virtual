﻿namespace NugetPackAndPush
{
    partial class OptionsDlg
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this._bnBrowseNuget = new System.Windows.Forms.Button();
            this._lblNugetPath = new System.Windows.Forms.Label();
            this._bnOK = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // _bnBrowseNuget
            // 
            this._bnBrowseNuget.Location = new System.Drawing.Point(383, 8);
            this._bnBrowseNuget.Name = "_bnBrowseNuget";
            this._bnBrowseNuget.Size = new System.Drawing.Size(75, 23);
            this._bnBrowseNuget.TabIndex = 0;
            this._bnBrowseNuget.Text = "Browse...";
            this._bnBrowseNuget.UseVisualStyleBackColor = true;
            this._bnBrowseNuget.Click += new System.EventHandler(this._bnBrowseNuget_Click);
            // 
            // _lblNugetPath
            // 
            this._lblNugetPath.AutoEllipsis = true;
            this._lblNugetPath.Location = new System.Drawing.Point(12, 10);
            this._lblNugetPath.Name = "_lblNugetPath";
            this._lblNugetPath.Size = new System.Drawing.Size(365, 18);
            this._lblNugetPath.TabIndex = 1;
            this._lblNugetPath.Text = "Nuget.exe Path: ";
            this._lblNugetPath.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // _bnOK
            // 
            this._bnOK.DialogResult = System.Windows.Forms.DialogResult.OK;
            this._bnOK.Location = new System.Drawing.Point(382, 227);
            this._bnOK.Name = "_bnOK";
            this._bnOK.Size = new System.Drawing.Size(75, 23);
            this._bnOK.TabIndex = 2;
            this._bnOK.Text = "OK";
            this._bnOK.UseVisualStyleBackColor = true;
            this._bnOK.Click += new System.EventHandler(this._bnOK_Click);
            // 
            // Options
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(470, 262);
            this.Controls.Add(this._bnOK);
            this.Controls.Add(this._lblNugetPath);
            this.Controls.Add(this._bnBrowseNuget);
            this.Name = "Options";
            this.Text = "Options";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button _bnBrowseNuget;
        private System.Windows.Forms.Label _lblNugetPath;
        private System.Windows.Forms.Button _bnOK;
    }
}