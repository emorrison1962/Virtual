﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NugetPackAndPush
{
    public interface IProcessObserver
    {
        void ProcessObserver_OutputDataReceived(object sender, DataReceivedEventArgs e);
        void ProcessObserver_ErrorDataReceived(object sender, DataReceivedEventArgs e);
    }
}
