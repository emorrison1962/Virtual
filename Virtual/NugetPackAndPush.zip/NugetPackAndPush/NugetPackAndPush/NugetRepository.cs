﻿using System;

namespace NugetPackAndPush
{
    public class NugetRepository
    {
        public string Name { get; set; }
        public Uri Uri { get; set; }
        public string ApiKey { get; set; }

        public NugetRepository(string name, string uri, string apiKey)
        {
            this.Name = name;
            this.Uri = new UriBuilder(uri).Uri;
            this.ApiKey = apiKey;
        }
    }
}
