﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NugetPackAndPush
{
    public class NugetContext
    {
        string _projectName;
        public string ProjectPath { get; set; }
        public string NugetPath { get; set; }
        public ReleaseType ReleaseType { get; set; }
        public bool UpdateNuSpec { get; set; }
        public string Server { get; set; }
        public NugetRepository NugetRepository { get; set; }
        public string ProjectName
        {
            get
            {
                if (null == _projectName)
                {
                    _projectName = Path.GetFileNameWithoutExtension(this.ProjectPath);
                }
                return _projectName;
            }
        }

        public NugetContext(NugetRepository repo, string nugetPath, string projectPath, ReleaseType releaseType, bool updateNuSpec)
        {
            this.NugetRepository = repo;
            this.NugetPath = nugetPath;
            this.ProjectPath = projectPath;
            this.ReleaseType = releaseType;
            this.UpdateNuSpec = updateNuSpec;

            if (!File.Exists(this.ProjectPath))
                throw new FileNotFoundException();
            if (!File.Exists(this.NugetPath))
                throw new FileNotFoundException();
        }
    }//class
}//ns
