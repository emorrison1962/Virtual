﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NugetPackAndPush
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            // Set the unhandled exception mode to force all Windows Forms errors
            // to go through our handler.
            Application.SetUnhandledExceptionMode(UnhandledExceptionMode.CatchException);

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            var form = new MainForm();
            SetExceptionHandler(form);
            form.StartPosition = FormStartPosition.CenterScreen;

            Application.Run(form);
        }

        static void SetExceptionHandler(MainForm form)
        {
            //if (!AppDomain.CurrentDomain.FriendlyName.EndsWith("vshost.exe"))
            {
                // Add the event handler for handling UI thread exceptions to the event.
                Application.ThreadException += form.Application_ThreadException;

                // Add the event handler for handling non-UI thread exceptions to the event. 
                AppDomain.CurrentDomain.UnhandledException += form.CurrentDomain_UnhandledException;
            }
        }


    }
}
