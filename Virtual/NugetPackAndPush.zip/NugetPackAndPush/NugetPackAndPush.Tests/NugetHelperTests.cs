﻿using NugetPackAndPush;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Diagnostics;

namespace NugetPackAndPush.Tests
{
    [TestClass()]
    public class NugetHelperTests
    {
        const string NUGET_PATH = @"C:\Program Files (x86)\NugetCLI\nuget.exe";
        const string PROJECT_PATH = @"c:\dev\simplification\merchants api\mixapi.flex.data.entities\MixApi.Flex.Data.Entities.csproj";


        [TestMethod()]
        public void GetVersionFromServerTest()
        {
            const string EPS_APIKEY = "EPS";
            const string EPS_NUGET_REPO = "http://us007-pc-itxx01/nuget/nuget/";
            const string GOEVO_APIKEY = "METX_CI_NugetServer2015!";
            const string GOEVO_NUGET_REPO = @"""http://us002-pc-tfs03.goevo.com/EVO NuGet Server/NuGet""";


            NugetRepository epsRepo = new NugetRepository("", EPS_NUGET_REPO, EPS_APIKEY);
            var ctx = new NugetContext(epsRepo, NUGET_PATH, PROJECT_PATH, ReleaseType.Alpha, false);
            var helper = new NugetHelper(ctx);
            helper.OutputDataReceived += NugetHelper_OutputDataReceived;

            //helper.GetVersionFromServer();
            new object();
        }


        [TestMethod()]
        public void PackAndPushTest()
        {
            const string NUGET_PATH = "C:\\Program Files (x86)\\NugetCLI\\nuget.exe";
            const string PROJECT_PATH = "c:\\dev\\simplification\\merchants api\\mixapi.flex.data.entities\\MixApi.Flex.Data.Entities.csproj";


            var repo = new NugetRepository("", "http://us007-pc-itxx01/nuget/nuget/", "EPS");
            //var repo = new NugetRepository("http://us007-pc-itxx01/nuget/", "EPS");
            var rt = ReleaseType.Alpha;
            var ctx = new NugetContext(repo, NUGET_PATH, PROJECT_PATH, rt, true);


            var helper = new NugetHelper(ctx);
            helper.OutputDataReceived += ProcessObserver_OutputDataReceived;
            helper.OutputErrorReceived += ProcessObserver_ErrorDataReceived;
            helper.PackAndPush();

            new object();
        }

        private void ProcessObserver_OutputDataReceived(object sender, DataReceivedEventArgs e)
        {
            if (null != e.Data)
            {
                var text = e.Data.ToString() + Environment.NewLine;
                Debug.WriteLine(e.Data.ToString());
            }
        }

        public void ProcessObserver_ErrorDataReceived(object sender, DataReceivedEventArgs e)
        {
            if (null != e.Data)
            {
                var text = e.Data.ToString() + Environment.NewLine;
                Debug.WriteLine(e.Data.ToString());
            }
        }

        private void NugetHelper_OutputDataReceived(object sender, DataReceivedEventArgs e)
        {
            if (null != e.Data)
            {
                var text = e.Data.ToString() + Environment.NewLine;

                //this.BeginInvoke((Action)delegate ()
                //{
                //    this._tbOutput.AppendText(text);
                //});

                Debug.WriteLine(e.Data.ToString());
            }
        }



        //[TestMethod()]
        //public void NugetHelperTest()
        //{
        //    Assert.Fail();
        //}

        //[TestMethod()]
        //public void PackAndPushTest()
        //{
        //    Assert.Fail();
        //}

        //[TestMethod()]
        //public void SpecTest()
        //{
        //    Assert.Fail();
        //}
    }
}