﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using NugetPackAndPush;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NugetPackAndPush.Tests
{
    [TestClass()]
    public class DependencyFinderTests
    {
        [TestMethod()]
        public void FindConsumersTest()
        {
            var finder = new DependencyFinder();
            var consumers = finder.FindConsumers("MixApi.Flex.Data.Entities");
            consumers.ForEach(x => Debug.WriteLine(x));
        }
    }
}